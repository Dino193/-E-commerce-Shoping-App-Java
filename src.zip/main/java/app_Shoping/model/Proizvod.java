package app_Shoping.model;



import java.util.Arrays;
import java.util.List;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.Lob;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;

@Entity
@Table(name = "Proizvod")
public class Proizvod {

	    @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private int Proizvod_ID;

	    @Column(nullable = false)
	    private String Ime_Proizvoda;

	    @Lob
	    @Column(length = 100000)
	    private byte[] Slika_Proizvoda;

	    @Column
	    private String Opis_Proizvoda;

	    @Column
	    private double Cena_Proizvoda;

	    @ManyToOne
	    @JoinColumn(name = "Kategorija_ID", nullable = false)
	    private Kategorija kategorija;

	    @ManyToOne
	    @JoinColumn(name = "Brand_ID", nullable = false)
	    private Brand brand;

	    @ManyToOne
	    @JoinColumn(name = "Skladiste_ID", nullable = false)
	    private SkladisteProizvoda skladisteProizvoda;
	   
	    /*
	    @ManyToOne
	    @JoinColumn(name = "user_id")
	    private User user;
	    */
	    
	    @ManyToMany(mappedBy = "orderedProducts")
	    private List<User> users;
	    
	    
	    @Transient // This ensures the field is not stored in the database, it's only for session use.
	    private int quantity;


	    // Constructors
	    public Proizvod() {}

	   



		public Proizvod(String ime_Proizvoda, byte[] slika_Proizvoda, String opis_Proizvoda, double cena_Proizvoda,
				Kategorija kategorija, Brand brand, SkladisteProizvoda skladisteProizvoda, List<User> users,
				int quantity) {
			super();
			Ime_Proizvoda = ime_Proizvoda;
			Slika_Proizvoda = slika_Proizvoda;
			Opis_Proizvoda = opis_Proizvoda;
			Cena_Proizvoda = cena_Proizvoda;
			this.kategorija = kategorija;
			this.brand = brand;
			this.skladisteProizvoda = skladisteProizvoda;
			this.users = users;
			this.quantity = quantity;
		}





		// Getters and Setters
	    public int getProizvod_ID() {
	        return Proizvod_ID;
	    }

	    public void setProizvod_ID(int proizvod_ID) {
	        Proizvod_ID = proizvod_ID;
	    }

	    public String getIme_Proizvoda() {
	        return Ime_Proizvoda;
	    }

	    public void setIme_Proizvoda(String ime_Proizvoda) {
	        Ime_Proizvoda = ime_Proizvoda;
	    }

	    public byte[] getSlika_Proizvoda() {
	        return Slika_Proizvoda;
	    }

	    public void setSlika_Proizvoda(byte[] slika_Proizvoda) {
	        Slika_Proizvoda = slika_Proizvoda;
	    }

	    public String getOpis_Proizvoda() {
	        return Opis_Proizvoda;
	    }

	    public void setOpis_Proizvoda(String opis_Proizvoda) {
	        Opis_Proizvoda = opis_Proizvoda;
	    }

	    public double getCena_Proizvoda() {
	        return Cena_Proizvoda;
	    }

	    public void setCena_Proizvoda(double cena_Proizvoda) {
	        Cena_Proizvoda = cena_Proizvoda;
	    }

	    public Kategorija getKategorija() {
	        return kategorija;
	    }

	    public void setKategorija(Kategorija kategorija) {
	        this.kategorija = kategorija;
	    }

	    public Brand getBrand() {
	        return brand;
	    }

	    public void setBrand(Brand brand) {
	        this.brand = brand;
	    }

	    public SkladisteProizvoda getSkladisteProizvoda() {
	        return skladisteProizvoda;
	    }

	    public void setSkladisteProizvoda(SkladisteProizvoda skladisteProizvoda) {
	        this.skladisteProizvoda = skladisteProizvoda;
	    }

	    
	    public int getQuantity() {
	        return quantity;
	    }

	    public void setQuantity(int quantity) {
	        this.quantity = quantity;
	    }
	    
	    
	/*    
	    public User getUser() {
			return user;
		}
	    

		public void setUser(User user) {
			this.user = user;
		}
		
		*/
			

		public List<User> getUsers() {
			return users;
		}



		public void setUsers(List<User> users) {
			this.users = users;
		}





		@Override
		public String toString() {
			return "Proizvod [Proizvod_ID=" + Proizvod_ID + ", Ime_Proizvoda=" + Ime_Proizvoda + ", Slika_Proizvoda="
					+ Arrays.toString(Slika_Proizvoda) + ", Opis_Proizvoda=" + Opis_Proizvoda + ", Cena_Proizvoda="
					+ Cena_Proizvoda + ", kategorija=" + kategorija + ", brand=" + brand + ", skladisteProizvoda="
					+ skladisteProizvoda + ", users=" + users + ", quantity=" + quantity + "]";
		}




	

		
	}