package app_Shoping.model;

import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name = "Brand")
public class Brand {

	
	   
	
	    @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private int Brand_ID;

	    @Column(nullable = false)
	    private String Ime_Brenda;

	    @Column
	    private String Opis_Brenda;

	    @OneToMany(mappedBy = "brand", cascade = CascadeType.ALL)
	    private List<Proizvod> proizvodi;

	
	    
	    public Brand() {}
	    

	    public Brand(String ime_Brenda, String opis_Brenda) {
	        this.Ime_Brenda = ime_Brenda;
	        this.Opis_Brenda = opis_Brenda;
	    }


	    
	    public int getBrand_ID() {
	        return Brand_ID;
	    }

	    public void setBrand_ID(int brand_ID) {
	        Brand_ID = brand_ID;
	    }

	    public String getIme_Brenda() {
	        return Ime_Brenda;
	    }

	    public void setIme_Brenda(String ime_Brenda) {
	        Ime_Brenda = ime_Brenda;
	    }

	    public String getOpis_Brenda() {
	        return Opis_Brenda;
	    }

	    public void setOpis_Brenda(String opis_Brenda) {
	        Opis_Brenda = opis_Brenda;
	    }

	    public List<Proizvod> getProizvodi() {
	        return proizvodi;
	    }

	    public void setProizvodi(List<Proizvod> proizvodi) {
	        this.proizvodi = proizvodi;
	    }

	    @Override
	    public String toString() {
	        return "Brand [Brand_ID=" + Brand_ID + ", Ime_Brenda=" + Ime_Brenda + ", Opis_Brenda=" + Opis_Brenda + "]";
	    }
}