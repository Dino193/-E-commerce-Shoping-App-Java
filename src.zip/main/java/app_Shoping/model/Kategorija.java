package app_Shoping.model;

import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name = "kategorija")
public class Kategorija {

	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int kategorijaID;

    @Column(nullable = false)
    private String imeKategorije;

    @Column
    private String opisKategorije;

    @OneToMany(mappedBy = "kategorija", cascade = CascadeType.ALL)
    private List<Proizvod> proizvodi;

	public Kategorija() {
		
	}

	public Kategorija(String imeKategorije, String opisKategorije, List<Proizvod> proizvodi) {
		super();
		this.imeKategorije = imeKategorije;
		this.opisKategorije = opisKategorije;
		this.proizvodi = proizvodi;
	}

	public int getKategorijaID() {
		return kategorijaID;
	}

	public void setKategorijaID(int kategorijaID) {
		this.kategorijaID = kategorijaID;
	}

	public String getImeKategorije() {
		return imeKategorije;
	}

	public void setImeKategorije(String imeKategorije) {
		this.imeKategorije = imeKategorije;
	}

	public String getOpisKategorije() {
		return opisKategorije;
	}

	public void setOpisKategorije(String opisKategorije) {
		this.opisKategorije = opisKategorije;
	}

	public List<Proizvod> getProizvodi() {
		return proizvodi;
	}

	public void setProizvodi(List<Proizvod> proizvodi) {
		this.proizvodi = proizvodi;
	}

	@Override
	public String toString() {
		return "Kategorija [kategorijaID=" + kategorijaID + ", imeKategorije=" + imeKategorije + ", opisKategorije="
				+ opisKategorije + ", proizvodi=" + proizvodi + "]";
	}

   
}
   
