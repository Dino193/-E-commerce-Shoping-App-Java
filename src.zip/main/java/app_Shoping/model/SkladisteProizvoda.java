package app_Shoping.model;

import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name = "SkladisteProizvoda")
public class SkladisteProizvoda {
	
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int Skladiste_ID;

    @Column(nullable = false)
    private String Naziv_Skladista;

    @Column
    private String Adressa;

    @Column
    private String Grad;

    @Column
    private String BrojTelefona;

    @OneToMany(mappedBy = "skladisteProizvoda", cascade = CascadeType.ALL)
    private List<Proizvod> proizvodi;

    // Constructors
    public SkladisteProizvoda() {}

    public SkladisteProizvoda(String naziv_Skladista, String adressa, String grad, String brojTelefona) {
        this.Naziv_Skladista = naziv_Skladista;
        this.Adressa = adressa;
        this.Grad = grad;
        this.BrojTelefona = brojTelefona;
    }

    // Getters and Setters
    public int getSkladiste_ID() {
        return Skladiste_ID;
    }

    public void setSkladiste_ID(int skladiste_ID) {
        Skladiste_ID = skladiste_ID;
    }

    public String getNaziv_Skladista() {
        return Naziv_Skladista;
    }

    public void setNaziv_Skladista(String naziv_Skladista) {
        Naziv_Skladista = naziv_Skladista;
    }

    public String getAdressa() {
        return Adressa;
    }

    public void setAdressa(String adressa) {
        Adressa = adressa;
    }

    public String getGrad() {
        return Grad;
    }

    public void setGrad(String grad) {
        Grad = grad;
    }

    public String getBrojTelefona() {
        return BrojTelefona;
    }

    public void setBrojTelefona(String brojTelefona) {
        BrojTelefona = brojTelefona;
    }

    public List<Proizvod> getProizvodi() {
        return proizvodi;
    }

    public void setProizvodi(List<Proizvod> proizvodi) {
        this.proizvodi = proizvodi;
    }

    @Override
    public String toString() {
        return "SkladisteProizvoda [Skladiste_ID=" + Skladiste_ID + ", Naziv_Skladista=" + Naziv_Skladista
                + ", Adressa=" + Adressa + ", Grad=" + Grad + ", BrojTelefona=" + BrojTelefona + "]";
    }
}