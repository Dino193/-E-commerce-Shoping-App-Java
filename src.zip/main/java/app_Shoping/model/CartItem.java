package app_Shoping.model;

public class CartItem {
	
	

    private Proizvod proizvod;
    
    private int quantity;

  
    public CartItem() {
		
	}

	public CartItem(Proizvod proizvod, int quantity) {
       
		this.proizvod = proizvod;
        this.quantity = quantity;
    }

   
    public Proizvod getProizvod() {
        return proizvod;
    }

    
    public void setProizvod(Proizvod proizvod) {
        this.proizvod = proizvod;
    }


    public int getQuantity() {
        return quantity;
    }

   
    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

   
    public double getTotalPrice() {
    	
        return this.proizvod.getCena_Proizvoda() * this.quantity;
    }


    @Override
    public String toString() {
        return "CartItem{" +
                "proizvod=" + proizvod.getIme_Proizvoda() +
                ", quantity=" + quantity +
                ", totalPrice=" + getTotalPrice() +
                '}';
    }



    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        CartItem cartItem = (CartItem) o;

        return proizvod != null ? proizvod.equals(cartItem.proizvod) : cartItem.proizvod == null;
    }

    @Override
    public int hashCode() {
        return proizvod != null ? proizvod.hashCode() : 0;
    }
}


