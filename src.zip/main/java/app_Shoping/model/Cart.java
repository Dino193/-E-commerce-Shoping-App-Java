package app_Shoping.model;



import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;


public class Cart {
	
	

    private Map<Proizvod, Integer> items = new HashMap<>();


    public void addProduct(Proizvod proizvod, int quantity) {
        
        items.put(proizvod, items.getOrDefault(proizvod, 0) + quantity);
    }

    
    public void removeProduct(Proizvod proizvod) {
    	
        items.remove(proizvod);
    }

    
    public void updateProductQuantity(Proizvod proizvod, int quantity) {
    	
        if (quantity > 0) {
            items.put(proizvod, quantity);
        } else {
            items.remove(proizvod); 
        }
    }

  
    public int getItemCount() {
    	
        return items.values().stream().mapToInt(Integer::intValue).sum();
    }


    public double calculateTotalPrice() {
    	
        double totalPrice = 0.0;
        
        for (Entry<Proizvod, Integer> entry : items.entrySet()) {
            Proizvod proizvod = entry.getKey();
            Integer quantity = entry.getValue();
            totalPrice += proizvod.getCena_Proizvoda() * quantity;
        }
        return totalPrice;
    }


    public Map<Proizvod, Integer> getItems() {
    	
        return items;
    }

  
    public void clear() {
    	
        items.clear();
    }
}


