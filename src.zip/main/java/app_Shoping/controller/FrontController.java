package app_Shoping.controller;



import java.io.IOException;
import java.security.Principal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import app_Shoping.uploadImage.*;
import app_Shoping.dto.ProductDto;
import app_Shoping.dto.UserDto;
import app_Shoping.model.Brand;

import app_Shoping.model.Kategorija;
import app_Shoping.model.Proizvod;
import app_Shoping.model.Role;
import app_Shoping.model.SkladisteProizvoda;
import app_Shoping.model.User;
import app_Shoping.repository.BrandRepository;
import app_Shoping.repository.KategorijaRepository;
import app_Shoping.repository.ProizvodRepository;
import app_Shoping.repository.RoleRepository;
import app_Shoping.repository.SkladisteProizvodaRepository;
import app_Shoping.repository.UserRepository;
import app_Shoping.service.ShoppingCartService;
import app_Shoping.service.UserService;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;







@Controller
public class FrontController {
	
	
    @Autowired
	private BrandRepository brandRepository;
    
    @Autowired
	private KategorijaRepository kategorijaRepository;
    
    @Autowired
	private SkladisteProizvodaRepository skladisteProizvodaRepository;
	
    @Autowired
	private ProizvodRepository proizvodRepository;
    
    @Autowired
    private UserService userService;
    
    @Autowired
    private UserRepository userRepository;
    
    @Autowired
    RoleRepository roleRepository;
    
    @Autowired
    private ShoppingCartService shoppingCartService;
	
	
	//TESTIRANJE START----------------------------------------------------------------------------------------------------------------------------------------------
    
	@GetMapping(value = "/index")
	public String loadPage() {
		
		return "index";
	}
	
	
	 @GetMapping("/product-info")
	    public String showProductInfo(Model model) {
		 
		 
	        List<Proizvod> allProducts = proizvodRepository.findAll(); // Fetch all products
	       
	        model.addAttribute("proizvodi", allProducts);
	        
	        return "product-info";  // Return the product-info.html page
	    }
	
	//TESTIRANJE END----------------------------------------------------------------------------------------------------------------------------------------------
	 
	 
   //IMAGE UPLOAD STAR----------------------------------------------------------------------------------------------------------------------------------------------
	 

	    @GetMapping("/image/{id}")
	    @ResponseBody
	    public ResponseEntity<byte[]> getImage(@PathVariable("id") int id) {
	    	
	        Proizvod proizvod = proizvodRepository.findById(id).orElse(null);
	        
	        if (proizvod != null && proizvod.getSlika_Proizvoda() != null) {
	            byte[] image = proizvod.getSlika_Proizvoda();
	            return ResponseEntity.ok()
	                    .contentType(MediaType.IMAGE_JPEG) // or MediaType.IMAGE_PNG depending on the image type
	                    .body(image);
	        }
	        return ResponseEntity.notFound().build();
	    }
	    
	    

	 
	//IMAGE UPLOAD END----------------------------------------------------------------------------------------------------------------------------------------------
	
	
	
	//LOGIN AND REGISTRATION START----------------------------------------------------------------------------------------------------------------------------------------------
	
	
	 // handler method to handle login request
    @GetMapping("/login")
    public String login(){
    	
        return "login";
    }
	
	
	// handler method to handle user registration form request
	 @GetMapping("/register")
	    public String showRegistrationForm(Model model){
	       
	        UserDto user = new UserDto();
	        
	        model.addAttribute("user", user);
	        
	        return "register";
	    }
	 
	 
	 // handler method to handle user registration form submit request
	    @PostMapping("/register/save")
	    public String registration(@Valid @ModelAttribute("user") UserDto userDto,
	                               BindingResult result,
	                               Model model){
	        User existingUser = userService.findUserByEmail(userDto.getEmail());

	        if(existingUser != null && existingUser.getEmail() != null && !existingUser.getEmail().isEmpty()){
	            result.rejectValue("email", null,
	                    "There is already an account registered with the same email");
	        }

	        if(result.hasErrors()){
	            model.addAttribute("user", userDto);
	            return "/register";
	        }

	        userService.saveUser(userDto);
	        return "redirect:/register?success";
	    }
	    
	    
	   
	  /*  @GetMapping("/users")
	    public String getUserList(Model model) {
	        List<UserDto> users = userService.getAllUsersWithOrderedProducts();
	        model.addAttribute("users", users);
	        return "users";  
	    }*/
	    
	   
	   /* @GetMapping("/users")
	    public String getUserList(Model model, HttpSession session ) {
	    	
	    	
	    	// Fetch the cart items from the session, if they exist
	        @SuppressWarnings("unchecked")
	        Map<Integer, Integer> cartItems = (Map<Integer, Integer>) session.getAttribute("cartItems");
	        if (cartItems == null) {
	            cartItems = new HashMap<>();
	        }

	        // Fetch products in the cart and calculate total price
	        List<Proizvod> proizvodi = shoppingCartService.getAllProductsInCart(cartItems);
	        double totalPrice = shoppingCartService.calculateTotalPrice(cartItems);

	        // Add cart-related data to the model
	        model.addAttribute("proizvodi", proizvodi);
	        model.addAttribute("totalPrice", totalPrice);

	        // Fetch users with their ordered products
	        List<UserDto> users = userService.getAllUsersWithOrderedProducts();  
	        model.addAttribute("users", users);

	        return "users";  
	    }*/
	    
	    
	    @GetMapping("/fetchOrderedProducts")
	    @ResponseBody
	    public List<ProductDto> fetchOrderedProducts(@RequestParam("email") String email) {
	    	
	        // Fetch ordered products by user email
	        List<ProductDto> orderedProducts = shoppingCartService.getOrderedProductsByUserEmail(email);

	        // Return the list of ordered products as JSON
	        return orderedProducts;
	    }
	    
	    @GetMapping("/users")
	    public String getUserList(Model model) {
	        List<UserDto> users = userService.getAllUsersWithOrderedProducts();

	        for (UserDto user : users) {
	            List<ProductDto> orderedProducts = shoppingCartService.getOrderedProductsByUserEmail(user.getEmail());
	            user.setOrderedProducts(orderedProducts != null ? orderedProducts : new ArrayList<>());  // Avoid null
	        }

	        model.addAttribute("users", users);
	        return "users";  // Make sure this maps to the correct Thymeleaf view
	    }




	    

	    
	   
	    @GetMapping("/userProfile")
	    public String usersProfile(Model model){
	    
            List<UserDto> users = userService.findAllUsers();
	        
            if (!users.isEmpty()) {
	            UserDto firstUser = users.get(0);  // Get the first user from the list
	            model.addAttribute("user", firstUser);  // Add the first user to the model
	        }
	        
	        
	    	
	        return "profileUser";
	        
	    
	    }

	    
	

	  
	 //LOGIN AND REGISTRATION END----------------------------------------------------------------------------------------------------------------------------------------------
	    
	    
     //PRODUCT START ----------------------------------------------------------------------------------------------------------------------------------------------
	    
	    @GetMapping("/addProduct")
	    public String showAddProductForm(Model model) {
	    	
	        Proizvod proizvod = new Proizvod();
	        
	        List<Kategorija> kategorije = kategorijaRepository.findAll();
	        List<Brand> brandovi = brandRepository.findAll();
	        List<SkladisteProizvoda> skladista = skladisteProizvodaRepository.findAll();

	        model.addAttribute("proizvod", proizvod);
	        model.addAttribute("kategorije", kategorije);
	        model.addAttribute("brandovi", brandovi);
	        model.addAttribute("skladista", skladista);

	        return "addProduct";
	    }

	    

	    @PostMapping("/saveProduct")
	    public String saveProduct(@ModelAttribute("Proizvod") Proizvod proizvod, 
	                              @RequestParam("image") MultipartFile imageFile, 
	                              BindingResult result, 
	                              Model model) {
	        // Check for validation errors
	        if (result.hasErrors()) {
	            model.addAttribute("kategorije", kategorijaRepository.findAll());
	            model.addAttribute("brandovi", brandRepository.findAll());
	            model.addAttribute("skladista", skladisteProizvodaRepository.findAll());
	            return "addProduct";
	        }

	        // Handle image file upload
	        if (!imageFile.isEmpty()) {
	            try {
	                // Check file size (example limit: 64MB)
	                if (imageFile.getSize() > 64 * 1024 * 1024) {
	                    model.addAttribute("message", "Image file is too large. Maximum size allowed is 64MB.");
	                    model.addAttribute("kategorije", kategorijaRepository.findAll());
	                    model.addAttribute("brandovi", brandRepository.findAll());
	                    model.addAttribute("skladista", skladisteProizvodaRepository.findAll());
	                    return "addProduct";
	                }
	                
	                // Resize the image and set it in the product
	                byte[] resizedImage = ImageUtils.resizeImage(imageFile);
	                proizvod.setSlika_Proizvoda(resizedImage);
	            } catch (IOException e) {
	                e.printStackTrace();
	                model.addAttribute("message", "Failed to upload image");
	                model.addAttribute("kategorije", kategorijaRepository.findAll());
	                model.addAttribute("brandovi", brandRepository.findAll());
	                model.addAttribute("skladista", skladisteProizvodaRepository.findAll());
	                return "addProduct";
	            }
	        }

	        // Save the product to the repository
	        try {
	            proizvodRepository.save(proizvod);
	            model.addAttribute("message", "Product saved successfully");
	        } catch (Exception e) {
	            e.printStackTrace();
	            model.addAttribute("message", "Failed to save product");
	            model.addAttribute("kategorije", kategorijaRepository.findAll());
	            model.addAttribute("brandovi", brandRepository.findAll());
	            model.addAttribute("skladista", skladisteProizvodaRepository.findAll());
	            return "addProduct";
	        }

	        // Redirect to the list of products with a success message
	        return "redirect:/listProducts";
	    }




	


	    
	    
	    @GetMapping("/listProducts")
	    public String addProduct(Model model) {
	        
	    	List<Proizvod> proizvodi = proizvodRepository.findAll();
	    	List<Kategorija> kategorije = kategorijaRepository.findAll();
	    	List<Brand> brandovi = brandRepository.findAll();
	    	List<SkladisteProizvoda> skladisteProizvoda = skladisteProizvodaRepository.findAll();
	    	
	    	model.addAttribute("proizvodi", proizvodi);
	    	model.addAttribute("kategorije", kategorije);
	    	model.addAttribute("brandovi", brandovi);
	        model.addAttribute("skladisteProizvoda", skladisteProizvoda);
	        
	        return "listProducts";
	    }
	    
	  
	    @GetMapping("/editProduct/{Proizvod_ID}")
	    public String showEditProductForm(@PathVariable int Proizvod_ID, Model model) {
	        Proizvod proizvod = proizvodRepository.findById(Proizvod_ID)
	            .orElseThrow(() -> new IllegalArgumentException("Invalid product ID: " + Proizvod_ID));
	        
	        List<Kategorija> kategorije = kategorijaRepository.findAll();
	        List<Brand> brandovi = brandRepository.findAll();
	        List<SkladisteProizvoda> skladista = skladisteProizvodaRepository.findAll();

	        model.addAttribute("proizvod", proizvod);
	        model.addAttribute("kategorije", kategorije);
	        model.addAttribute("brandovi", brandovi);
	        model.addAttribute("skladista", skladista);

	        return "edit-product";
	    }

	
	    @PostMapping("/updateProduct/{Proizvod_ID}")
	    public String updateProduct(
	            @PathVariable int Proizvod_ID,
	            @ModelAttribute("Proizvod") Proizvod proizvod,
	            @RequestParam("image") MultipartFile imageFile) {

	        Proizvod existingProizvod = proizvodRepository.findById(Proizvod_ID)
	            .orElseThrow(() -> new IllegalArgumentException("Invalid product ID: " + Proizvod_ID));
	        
	        existingProizvod.setIme_Proizvoda(proizvod.getIme_Proizvoda());
	        existingProizvod.setOpis_Proizvoda(proizvod.getOpis_Proizvoda());
	        existingProizvod.setCena_Proizvoda(proizvod.getCena_Proizvoda());
	        existingProizvod.setKategorija(proizvod.getKategorija());
	        existingProizvod.setBrand(proizvod.getBrand());
	        existingProizvod.setSkladisteProizvoda(proizvod.getSkladisteProizvoda());
	        
	        // Handle image file upload
	        if (!imageFile.isEmpty()) {
	            try {
	                byte[] imageBytes = imageFile.getBytes();
	                existingProizvod.setSlika_Proizvoda(imageBytes);
	            } catch (IOException e) {
	                e.printStackTrace();
	                // Handle the error appropriately in a real-world application
	            }
	        }

	        proizvodRepository.save(existingProizvod);
	        
	        return "redirect:/listProducts";  // Adjust this to the correct path
	    }

	    @GetMapping("/deleteProduct/{Proizvod_ID}")
	    public String deleteProduct(@PathVariable int Proizvod_ID, Model model) {
	    	
	        try {
	            // Find the product by ID
	            Proizvod proizvod = proizvodRepository.findById(Proizvod_ID)
	                .orElseThrow(() -> new IllegalArgumentException("Invalid product ID: " + Proizvod_ID));

	            // Delete the product
	            proizvodRepository.delete(proizvod);

	            // Add a success message to the model
	            model.addAttribute("message", "Product deleted successfully");

	        } catch (Exception e) {
	            // Add an error message to the model in case of failure
	            model.addAttribute("message", "Failed to delete product: " + e.getMessage());
	            e.printStackTrace();
	        }

	        // Redirect to the list of products
	        return "redirect:/listProducts";
	    }
	    
	//PRODUCT END----------------------------------------------------------------------------------------------------------------------------------------------  
	    
	    
	 //CRUD OPERATION START----------------------------------------------------------------------------------------------------------------------------------------------
	
	    @GetMapping("/edit/{id}")
	    public String showUpdateForm(@PathVariable("id") long id, Model model) {
	        User user = userRepository.findById(id)
	          .orElseThrow(() -> new IllegalArgumentException("Invalid user Id: " + id));
	        model.addAttribute("user", user);
	        return "update-user";  // Ensure that "update-user.html" exists in your templates folder
	    }

	    @PostMapping("/update/{id}")
	    public String updateUser(@PathVariable("id") long id, @Valid User user, BindingResult result, Model model) {
	        if (result.hasErrors()) {
	            user.setId(id);  // This ensures the correct user is being updated
	            return "update-user";
	        }
	        userRepository.save(user);
	        return "redirect:/users";
	    }

	    @GetMapping("/delete/{id}")
	    public String deleteUser(@PathVariable("id") long id, Model model) {
	        User user = userRepository.findById(id)
	          .orElseThrow(() -> new IllegalArgumentException("Invalid user Id: " + id));
	        userRepository.delete(user);
	        return "redirect:/users";
	    }

	    @GetMapping("/addUser")
	    public String addUser(Model model) {
	        UserDto userDto = new UserDto();
	        List<Role> roles = roleRepository.findAll();
	        model.addAttribute("user", userDto);
	        model.addAttribute("roles", roles);
	        return "addUser";  // Ensure that "addUser.html" exists in your templates folder
	    }

	    @PostMapping("/saveUser")
	    public String saveUser(@ModelAttribute("user") @Valid UserDto userDto, BindingResult result, RedirectAttributes redirectAttributes) {
	        if (result.hasErrors()) {
	            redirectAttributes.addFlashAttribute("message", "Save Failure");
	            return "redirect:/users/addUser";
	        }

	        if (userService.saveUser(userDto)) {
	            redirectAttributes.addFlashAttribute("message", "Save Success");
	            return "redirect:/users";
	        }

	        redirectAttributes.addFlashAttribute("message", "Save Failure");
	        return "redirect:/users/addUser";
	    }
	
		
	    
	 //CRUD OPERATION END----------------------------------------------------------------------------------------------------------------------------------------------   
	
	 @GetMapping(value = "/mainShopPage")
	 public String kategorijaPage(Model model) {
		 
	   // List<Kategorija> kategorije = kategorijaRepository.findAll();
	    List<Proizvod> proizvodi = proizvodRepository.findAll();
	        
	   // model.addAttribute("kategorije", kategorije);
	    model.addAttribute("proizvodi", proizvodi);
	        
	    return "shop-index"; 
	    
	 }
        
        
	 
	 
	    @GetMapping("/shopBlog")
	    public String shopBlog() {
			
	        
			return "shop-blog";
	    }
		
		
 //SHOP CART START-----------------------------------------------------------------------------------------------------------------	

	   
	   /* @PostMapping("/cart/add")
	    public String addToCart(@RequestParam("productId") Integer productId, @RequestParam("quantity") Integer quantity, HttpSession session) {
	        // Retrieve or initialize the cartItems from the session
	        @SuppressWarnings("unchecked")
	        Map<Integer, Integer> cartItems = (Map<Integer, Integer>) session.getAttribute("cartItems");
	        if (cartItems == null) {
	            cartItems = new HashMap<>();
	            session.setAttribute("cartItems", cartItems);
	        }

	        // Use the service to add the product
	        shoppingCartService.addProduct(cartItems, productId, quantity);

	        // Redirect to the shopping cart page
	        return "redirect:/cart";
	    }*/
	    
	    @PostMapping("/cart/add")
	    public String addToCart(@RequestParam("productId") Integer productId, 
	                            @RequestParam("quantity") Integer quantity, 
	                            HttpSession session, 
	                            Principal principal) {
	        
	        // Retrieve or initialize the cartItems from the session
	        @SuppressWarnings("unchecked")
	        Map<Integer, Integer> cartItems = (Map<Integer, Integer>) session.getAttribute("cartItems");
	        if (cartItems == null) {
	            cartItems = new HashMap<>();
	            session.setAttribute("cartItems", cartItems);
	        }

	        // Use the shoppingCartService to add the product to the cart (in session)
	        shoppingCartService.addProduct(cartItems, productId, quantity);
	        
	        // Now, also save the product to the logged-in user's ordered products
	        // Fetch the logged-in user (assuming you're using Spring Security)
	        User user = userService.findUserByEmail(principal.getName());
	        
	        // Fetch the product entity from the repository using its ID
	        Optional<Proizvod> proizvodOpt = proizvodRepository.findById(productId);
	        if (proizvodOpt.isPresent()) {
	            Proizvod product = proizvodOpt.get();
	            List<Proizvod> orderedProducts = new ArrayList<>();
	            orderedProducts.add(product);
	            
	            // Add the product to the user's ordered products
	            shoppingCartService.addProductsToUser(user, orderedProducts);
	        }
	        
	        // Redirect to the shopping cart page after adding the product
	        return "redirect:/cart";
	    }


	    @GetMapping("/cart")
	    public String viewCart(Model model, HttpSession session) {
	        // Retrieve or initialize the cartItems from the session
	        @SuppressWarnings("unchecked")
	        Map<Integer, Integer> cartItems = (Map<Integer, Integer>) session.getAttribute("cartItems");
	        if (cartItems == null) {
	            cartItems = new HashMap<>();
	        }

	        // Use the service to fetch products and calculate the total price
	        List<Proizvod> proizvodi = shoppingCartService.getAllProductsInCart(cartItems);
	        double totalPrice = shoppingCartService.calculateTotalPrice(cartItems);

	        // Add data to the model for rendering in the cart view
	        model.addAttribute("proizvodi", proizvodi);
	        model.addAttribute("totalPrice", totalPrice);

	        // Return the cart page template
	        return "shop-cart";  // This refers to cart.html (the Thymeleaf template)
	    }
	    
	    @PostMapping("/cart/remove")
	    @ResponseBody
	    public Map<String, Object> removeProductFromCart(@RequestBody Map<String, Object> payload, HttpSession session) {
	        Integer productId = (Integer) payload.get("productId");

	        // Retrieve or initialize the cartItems from the session
	        @SuppressWarnings("unchecked")
	        Map<Integer, Integer> cartItems = (Map<Integer, Integer>) session.getAttribute("cartItems");
	        if (cartItems != null) {
	            // Use the service to remove the product from the cart
	            shoppingCartService.removeProduct(cartItems, productId);
	        }

	        // Return success response
	        Map<String, Object> response = new HashMap<>();
	        response.put("success", true);
	        return response;
	    }
	    
	    
	    @PostMapping("/cart/update")
	    public String updateCart(@RequestParam("productId") Integer productId, @RequestParam("quantity") Integer quantity, HttpSession session) {
	        // Retrieve the cart from the session
	        @SuppressWarnings("unchecked")
	        Map<Integer, Integer> cartItems = (Map<Integer, Integer>) session.getAttribute("cartItems");
	        if (cartItems != null) {
	            // Update the quantity for the specified product
	            if (quantity > 0) {
	                cartItems.put(productId, quantity);
	            } else {
	                // If quantity is 0 or less, remove the product from the cart
	                cartItems.remove(productId);
	            }
	        }
	        
	        // Redirect back to the cart page
	        return "redirect:/shop-cart";
	    }
	    
	    
	    @PostMapping("/checkout")
	    public String checkout(HttpSession session, Model model) {
	        // Get current logged-in user
	        User user = (User) session.getAttribute("currentUser");
	        
	        if (user == null) {
	            return "redirect:/login";  // Redirect to login if user is not logged in
	        }

	        // Get cart items from the session
	        @SuppressWarnings("unchecked")
	        Map<Integer, Integer> cartItems = (Map<Integer, Integer>) session.getAttribute("cartItems");
	        
	        if (cartItems == null || cartItems.isEmpty()) {
	            model.addAttribute("message", "Your cart is empty.");
	            return "redirect:/cart";
	        }

	        // Save the order (attach the ordered products to the user by email)
	        List<Proizvod> orderedProducts = shoppingCartService.saveOrder(user, cartItems);

	        // Clear the cart after checkout
	        session.removeAttribute("cartItems");

	        // Add ordered products and user email to the model
	        model.addAttribute("orderedProducts", orderedProducts);
	        model.addAttribute("userEmail", user.getEmail());

	        return "order-confirmation";  // Redirect to order confirmation page
	    }

	    
	    @GetMapping("/orderConfirmation")
	    public String showOrderConfirmation() {
	       

	        return "Order-Confirmation"; 
	    }

	    @PostMapping("/orderConfirmation/add")
	    public String confirmOrder(@RequestParam("productId") Integer productId, 
	                               @RequestParam("quantity") Integer quantity, 
	                               HttpSession session, 
	                               Model model) {
	        // Retrieve or initialize the cartItems from the session
	        @SuppressWarnings("unchecked")
	        Map<Integer, Integer> cartItems = (Map<Integer, Integer>) session.getAttribute("cartItems");
	        if (cartItems == null) {
	            cartItems = new HashMap<>();
	            session.setAttribute("cartItems", cartItems);
	        }

	        // Use the service to add the product to the cart
	        shoppingCartService.addProduct(cartItems, productId, quantity);

	        // Fetch all products in the cart (assuming getAllProductsInCart method exists)
	        List<Proizvod> orderedProducts = shoppingCartService.getAllProductsInCart(cartItems);

	        // Ensure orderedProducts is not null or empty
	        if (orderedProducts == null || orderedProducts.isEmpty()) {
	            model.addAttribute("error", "No products found in the cart.");
	            return "error"; // Display an error page or handle gracefully
	        }

	        // Add ordered products to the model
	        model.addAttribute("orderedProducts", orderedProducts);

	        // Redirect to the order confirmation page
	        return "order-confirmation";  // This will render the order-confirmation.html Thymeleaf template
	    }


	

	

	//SHOP CART END-----------------------------------------------------------------------------------------------------------------	

	    @GetMapping("/shopCategory")
	    public String shopCategory(
	            @RequestParam(value = "kategorija", required = false) List<Integer> Kategorija_ID,
	            @RequestParam(value = "lower", required = false) Double lowerPrice,
	            @RequestParam(value = "upper", required = false) Double upperPrice,
	            @RequestParam(value = "categoryLetter", required = false) String categoryLetter,
	            @RequestParam(value = "selectedProductName", required = false) String selectedProductName, 
	            Model model) {

	        // Default values for price if not provided
	        if (lowerPrice == null) lowerPrice = 0.0;
	        if (upperPrice == null) upperPrice = Double.MAX_VALUE;

	        List<Integer> filteredCategoryIds = null;

	        // If a category letter is selected, fetch categories starting with the selected letter
	        if (categoryLetter != null && !categoryLetter.isEmpty()) {
	            List<Kategorija> kategorije = kategorijaRepository.findByImeKategorijeStartingWithIgnoreCase(categoryLetter);
	            filteredCategoryIds = kategorije.stream()
	                    .map(Kategorija::getKategorijaID)
	                    .collect(Collectors.toList());
	        }

	        // Combine filteredCategoryIds with the selected categories
	        if (Kategorija_ID != null && !Kategorija_ID.isEmpty()) {
	            if (filteredCategoryIds != null) {
	                filteredCategoryIds.addAll(Kategorija_ID);
	            } else {
	                filteredCategoryIds = Kategorija_ID;
	            }
	        }

	        List<Proizvod> filteredProducts;

	        // If no categories are specified, fetch all products, else filter by categories and price range
	        if (filteredCategoryIds == null || filteredCategoryIds.isEmpty()) {
	            filteredProducts = proizvodRepository.findByIme_ProizvodaContainingIgnoreCaseAndCena_ProizvodaBetween(
	                    selectedProductName == null ? "" : selectedProductName,
	                    lowerPrice, upperPrice);
	        } else {
	            filteredProducts = proizvodRepository.findByIme_ProizvodaContainingIgnoreCaseAndKategorija_KategorijaIDInAndCena_ProizvodaBetween(
	                    selectedProductName == null ? "" : selectedProductName,
	                    filteredCategoryIds, lowerPrice, upperPrice);
	        }

	        // Fetch all categories for the dropdown
	        List<Kategorija> kategorije = kategorijaRepository.findAll();

	        // Fetch all product names for the dropdown list
	        List<String> productNames = proizvodRepository.findDistinctProductNames();

	        // Add the filtered products, categories, and product names to the model
	        model.addAttribute("proizvodi", filteredProducts);
	        model.addAttribute("kategorije", kategorije);
	        model.addAttribute("selectedCategories", Kategorija_ID);
	        model.addAttribute("lowerPrice", lowerPrice);
	        model.addAttribute("upperPrice", upperPrice);
	        model.addAttribute("categoryLetter", categoryLetter);
	        model.addAttribute("productNames", productNames);
	        model.addAttribute("selectedProductName", selectedProductName);

	        return "shop-category";
	    }

	    
	    
	    
	 
	 

	    
	    
	    
	    
	    
	    
		
	    @GetMapping("/shopBrand") 
	  	public String shopBrand(Model model) {
	    	
	    	
	    	List<Brand>brends = brandRepository.findAll();
	    	
	    	
	    	model.addAttribute("brends",brends);
	      	
	      	
	      	return "shop-brand";
	  		
	  	}
	    
		
		@GetMapping("/shopChekout")
	    public String shopChekout() {
			
	        return "shop-chekout";
	    }

		
		@GetMapping("/shopConfirmation")
	    public String shopConfirmation() {
			
	        
			return "shop-confirmation";
	    }
		
		
		
		@GetMapping("/shopContact") 
	    public String shopContact() {
			
	        return "shop-contact";
	    }

		
		
		
	    @GetMapping("/shopLogin")
		public String shopLogin() {
	    	
	    	
	    	return "shop-login";
			
		}

	    
		@GetMapping("/shopRegister")
	    public String shopRegister() {
			
	        
			return "shop-register";
	    }
		
		

		@GetMapping("/singleBlog") 
	    public String singleBlog() {
			
	        
			return "single-blog";
	    }
		
		
	    @GetMapping("/trackingOrder")
			public String trackingOrder() {
		    	
		    	
		    	return "tracking-order";
				
			}
			

	    
	  
	 
	   //SINGLE PAGE PRODUCTS START-----------------------------------------------------------------------------------------------------------------
	    
	    
	    
	    @GetMapping("/single-product/{id}")
	    public String getProductDetails(@PathVariable("id") int Proizvod_ID, Model model) {
	    	
	        Proizvod proizvod = proizvodRepository.findById(Proizvod_ID).orElse(null);
	        
	        model.addAttribute("proizvod", proizvod);
	        
	        return "single-product";
	    }
		
	    
		
		@GetMapping("/elektricnaKosilica")
	    public String elektricnaKosilicaSingleProduct(Model model) {
			
			
			List<Kategorija> kategorije = kategorijaRepository.findAll();
	 	    List<Proizvod> proizvodi = proizvodRepository.findAll();
	 	        
	 	    model.addAttribute("kategorije", kategorije);
	 	    model.addAttribute("proizvodi", proizvodi);
			
			
	        return "Elektricna-Kosilica-Za-Travu-Single-Page";
	   
		}
		
		
		@GetMapping("/Cekic") 
	    public String cekicSingleProduct(Model model) {
			
			
			List<Kategorija> kategorije = kategorijaRepository.findAll();
	 	    List<Proizvod> proizvodi = proizvodRepository.findAll();
	 	        
	 	    model.addAttribute("kategorije", kategorije);
	 	    model.addAttribute("proizvodi", proizvodi);
			
	        return "Cekic-Sa-Zaobljenom-Glavom-Single-Page";
	   
		}
		
		
		
		
		@GetMapping("/plavoUlje")
	    public String plavoUljeSingleProduct(Model model) {
			
			
			List<Kategorija> kategorije = kategorijaRepository.findAll();
	 	    List<Proizvod> proizvodi = proizvodRepository.findAll();
	 	        
	 	    model.addAttribute("kategorije", kategorije);
	 	    model.addAttribute("proizvodi", proizvodi);
			
	        return "Plavo-Ulje-Za-Zimsko-Prskanje-Single-Page";
	   
		}
		
		
		@GetMapping("/Lopata")
	    public String lopataSingleProduct(Model model) {
			
			
			List<Kategorija> kategorije = kategorijaRepository.findAll();
	 	    List<Proizvod> proizvodi = proizvodRepository.findAll();
	 	        
	 	    model.addAttribute("kategorije", kategorije);
	 	    model.addAttribute("proizvodi", proizvodi);
			
	        return "Lopata-Single-Page";
	   
		}
		
		
		
		@GetMapping("/traktorskaKosilica")
	    public String traktorskaKosilicaSingleProduct(Model model) {
			
			
			List<Kategorija> kategorije = kategorijaRepository.findAll();
	 	    List<Proizvod> proizvodi = proizvodRepository.findAll();
	 	        
	 	    model.addAttribute("kategorije", kategorije);
	 	    model.addAttribute("proizvodi", proizvodi);
			
	        return "Traktorska-Kosilica-Single-Page";
	   
		}
		
		
		
		
		@GetMapping("/pistoljZaPrskanjeVoca") 
	    public String pistoljSingleProduct(Model model) {
			
			
			List<Kategorija> kategorije = kategorijaRepository.findAll();
	 	    List<Proizvod> proizvodi = proizvodRepository.findAll();
	 	        
	 	    model.addAttribute("kategorije", kategorije);
	 	    model.addAttribute("proizvodi", proizvodi);
			
	        return "Pistolj-Za-Prskanje-Voca-Single-Page";
	   
		}
		
		
		@GetMapping("/busilica") 
	    public String busilicaSingleProduct(Model model) {
			
			
			List<Kategorija> kategorije = kategorijaRepository.findAll();
	 	    List<Proizvod> proizvodi = proizvodRepository.findAll();
	 	        
	 	    model.addAttribute("kategorije", kategorije);
	 	    model.addAttribute("proizvodi", proizvodi);
			
	        return "Busilica-Single-Page";
	   
		}
		
		
		@GetMapping("/benziskaKosilica") 
	    public String benziskaKosilicaSingleProduct(Model model) {
			
			
			List<Kategorija> kategorije = kategorijaRepository.findAll();
	 	    List<Proizvod> proizvodi = proizvodRepository.findAll();
	 	        
	 	    model.addAttribute("kategorije", kategorije);
	 	    model.addAttribute("proizvodi", proizvodi);
			
			
	        return "Benziska-Kosilica-Single-Page";
	   
		}
		
		
		
		
		@GetMapping("/posuda") 
	    public String posudaSingleProduct(Model model) {
			
			
			List<Kategorija> kategorije = kategorijaRepository.findAll();
	 	    List<Proizvod> proizvodi = proizvodRepository.findAll();
	 	        
	 	    model.addAttribute("kategorije", kategorije);
	 	    model.addAttribute("proizvodi", proizvodi);
			
			
	        return "Posuda-Za-Prskanje-Single-Page";
	   
		}
		
		
	 //SINGLE PAGE PRODUCTS END----------------------------------------------------------------------------------
	   
	 
	 
    }




