package app_Shoping.uploadImage;

import org.springframework.web.multipart.MultipartFile;

import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.IOException;

import javax.imageio.ImageIO;

public class ImageUtils {
	
	private static final int MAX_IMAGE_SIZE = 64 * 1024 * 1024;
	
	public static byte[] resizeImage(MultipartFile imageFile) throws IOException {

	    BufferedImage originalImage = ImageIO.read(imageFile.getInputStream());

	    if (originalImage == null) {
	        throw new IOException("Invalid image file.");
	    }

	    // Create a resized image with the desired dimensions
	    BufferedImage resizedImage = new BufferedImage(800, 600, BufferedImage.TYPE_INT_RGB);

	    // Get the graphics2D object
	    Graphics2D graphics = resizedImage.createGraphics();

	    // Use rendering hints for better image quality during the scaling process
	    graphics.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);
	    graphics.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
	    graphics.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

	    // Draw the original image to the resized image
	    graphics.drawImage(originalImage.getScaledInstance(800, 600, Image.SCALE_SMOOTH), 0, 0, 800, 600, null);

	    // Dispose of the graphics context to release resources
	    graphics.dispose();

	    // Convert the resized image to a byte array
	    ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
	    ImageIO.write(resizedImage, "jpg", outputStream);
	    byte[] resizedImageData = outputStream.toByteArray();

	    // Check if the resized image is too large
	    if (resizedImageData.length > MAX_IMAGE_SIZE) { // Define MAX_IMAGE_SIZE to a suitable value
	        throw new IOException("Resized image is too large to be stored in the database.");
	    }

	    return resizedImageData;
	}

}