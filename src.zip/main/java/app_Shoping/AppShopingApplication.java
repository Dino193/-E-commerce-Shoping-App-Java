package app_Shoping;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AppShopingApplication {

	public static void main(String[] args) {
		SpringApplication.run(AppShopingApplication.class, args);
	}

}
