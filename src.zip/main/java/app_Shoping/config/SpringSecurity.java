package app_Shoping.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;

import app_Shoping.model.User;
import jakarta.servlet.http.HttpServletResponse;


@Configuration
@EnableWebSecurity
public class SpringSecurity {
	
	
	 @Autowired
	 private UserDetailsService userDetailsService;

	    @Bean
	    public static PasswordEncoder passwordEncoder(){
	        return new BCryptPasswordEncoder();
	    }

	   
	    @Bean
	    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
	        http.csrf(AbstractHttpConfigurer::disable)
	            .authorizeHttpRequests(authorize -> authorize
	            	.requestMatchers("/users/**", "/listProducts").hasRole("ADMIN") // Restrict access to /users/** to ADMIN role	
	                .requestMatchers("/register/**", "/login", "/resources/**", "/static/**", "/css/**", "/js/**", "/images/**").permitAll()
	                .anyRequest().authenticated()
	            )
	            .formLogin(form -> form
	                .loginPage("/login")
	                .loginProcessingUrl("/login")
	                .defaultSuccessUrl("/mainShopPage", true)
	                .permitAll()
	            )
	            .logout(logout -> logout
	                .logoutRequestMatcher(new AntPathRequestMatcher("/logout"))
	                .logoutSuccessUrl("/login?logout")
	                .permitAll()
	            )
	            
	            .exceptionHandling(exceptionHandling -> exceptionHandling
	                    .accessDeniedHandler((request, response, accessDeniedException) -> {
	                        response.setStatus(HttpServletResponse.SC_FORBIDDEN);
	                        
	                        // Retrieve the authenticated user's name
	                        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
	                        String userName = (auth != null && auth.getName() != null) ? auth.getName() : "Nepoznati Korisnik";
	                        
	                        // Custom error message with the user's name
	                        String errorMessage = "Ovaj email: " + userName + ", nema dozovolu da pristupi ovoj stranici!!";
	                        response.getWriter().write(errorMessage);
	                    })
	                );
	        
	        return http.build();
	    }


	    @Autowired
	    public void configureGlobal(AuthenticationManagerBuilder auth) throws Exception {
	        auth
	                .userDetailsService(userDetailsService)
	                .passwordEncoder(passwordEncoder());
	    }
	}
	


