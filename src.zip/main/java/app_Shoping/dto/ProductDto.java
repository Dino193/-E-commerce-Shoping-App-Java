package app_Shoping.dto;

import java.util.List;

import app_Shoping.model.Brand;
import app_Shoping.model.Kategorija;
import app_Shoping.model.SkladisteProizvoda;
import jakarta.persistence.Transient;

public class ProductDto {
	
	

    private int proizvodId;
    
    private String imeProizvoda;
    
    private String opisProizvoda;
    
    private double cenaProizvoda;
    
    private String base64Image; // Field to store the Base64 image string
    
    private Kategorija kategorija;
    
    private Brand brand;
    
    private SkladisteProizvoda skladisteProizvoda;
    

    // Default constructor
    public ProductDto(String string) {
    }

    // Parameterized constructor
    public ProductDto(int proizvodId, String imeProizvoda, String opisProizvoda, double cenaProizvoda, String base64Image,
                      Kategorija kategorija, Brand brand, SkladisteProizvoda skladisteProizvoda) {
        this.proizvodId = proizvodId;
        this.imeProizvoda = imeProizvoda;
        this.opisProizvoda = opisProizvoda;
        this.cenaProizvoda = cenaProizvoda;
        this.base64Image = base64Image;
        this.kategorija = kategorija;
        this.brand = brand;
        this.skladisteProizvoda = skladisteProizvoda;
    }

    public ProductDto() {
		// TODO Auto-generated constructor stub
	}

	// Getters and setters
    public int getProizvodId() {
        return proizvodId;
    }

    public void setProizvodId(int proizvodId) {
        this.proizvodId = proizvodId;
    }

    public String getImeProizvoda() {
        return imeProizvoda;
    }

    public void setImeProizvoda(String imeProizvoda) {
        this.imeProizvoda = imeProizvoda;
    }

    public String getOpisProizvoda() {
        return opisProizvoda;
    }

    public void setOpisProizvoda(String opisProizvoda) {
        this.opisProizvoda = opisProizvoda;
    }

    public double getCenaProizvoda() {
        return cenaProizvoda;
    }

    public void setCenaProizvoda(double cenaProizvoda) {
        this.cenaProizvoda = cenaProizvoda;
    }

    public String getBase64Image() {
        return base64Image;
    }

    public void setBase64Image(String base64Image) {
        this.base64Image = base64Image;
    }

    public Kategorija getKategorija() {
        return kategorija;
    }

    public void setKategorija(Kategorija kategorija) {
        this.kategorija = kategorija;
    }

    public Brand getBrand() {
        return brand;
    }

    public void setBrand(Brand brand) {
        this.brand = brand;
    }

    public SkladisteProizvoda getSkladisteProizvoda() {
        return skladisteProizvoda;
    }

    public void setSkladisteProizvoda(SkladisteProizvoda skladisteProizvoda) {
        this.skladisteProizvoda = skladisteProizvoda;
    }
    
    
 

    @Override
    public String toString() {
        return "ProductDto{" +
                "proizvodId=" + proizvodId +
                ", imeProizvoda='" + imeProizvoda + '\'' +
                ", opisProizvoda='" + opisProizvoda + '\'' +
                ", cenaProizvoda=" + cenaProizvoda +
                ", base64Image='" + base64Image + '\'' +
                ", kategorija=" + kategorija +
                ", brand=" + brand +
                ", skladisteProizvoda=" + skladisteProizvoda +
                '}';
    }
}
