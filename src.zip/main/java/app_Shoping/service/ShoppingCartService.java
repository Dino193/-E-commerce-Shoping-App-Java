package app_Shoping.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import app_Shoping.dto.ProductDto;
import app_Shoping.model.Proizvod;
import app_Shoping.model.User;
import app_Shoping.repository.ProizvodRepository;
import app_Shoping.repository.UserRepository;


@Service
public class ShoppingCartService {
	
	

	@Autowired
    private ProizvodRepository proizvodRepository;
	
	@Autowired
	private UserRepository userRepository;

    // Retrieves all products currently in the cart
    public List<Proizvod> getAllProductsInCart(Map<Integer, Integer> cartItems) {
        // Fetch products from the repository based on product IDs in the cart
        return proizvodRepository.findAllById(cartItems.keySet());
    }
    
    
    public List<Proizvod> getProductsFromCart(Map<Integer, Integer> cartItems) {
        // Fetch products based on product IDs in the cart
        return proizvodRepository.findAllById(cartItems.keySet());
    }

    // Calculates the total price of all items in the cart
    public double calculateTotalPrice(Map<Integer, Integer> cartItems) {
        double totalPrice = 0.0;
        for (Map.Entry<Integer, Integer> entry : cartItems.entrySet()) {
            Integer proizvodId = entry.getKey();
            Integer quantity = entry.getValue();
            Optional<Proizvod> optionalProizvod = proizvodRepository.findById(proizvodId);
            if (optionalProizvod.isPresent()) {
                Proizvod proizvod = optionalProizvod.get();
                totalPrice += proizvod.getCena_Proizvoda() * quantity;
            }
        }
        return totalPrice;
    }

    // Adds a product to the cart with the specified quantity
    @Transactional
    public void addProduct(Map<Integer, Integer> cartItems, Integer proizvodId, int quantity) {
        cartItems.put(proizvodId, cartItems.getOrDefault(proizvodId, 0) + quantity);
    }

    // Updates the quantity of a product in the cart
    @Transactional
    public void updateProduct(Map<Integer, Integer> cartItems, Integer proizvodId, int quantity) {
        if (quantity > 0) {
            cartItems.put(proizvodId, quantity);
        } else {
            cartItems.remove(proizvodId);
        }
    }

    // Removes a product from the cart
    @Transactional
    public void removeProduct(Map<Integer, Integer> cartItems, Integer proizvodId) {
        cartItems.remove(proizvodId);
    }

    // Processes the checkout and clears the cart
    @Transactional
    public void checkout(Map<Integer, Integer> cartItems) {
        // Process checkout logic (e.g., save order to database, send confirmation email)
        cartItems.clear();
    }
    
    
    @Transactional
    public List<Proizvod> saveOrder(User user, Map<Integer, Integer> cartItems) {
        List<Proizvod> orderedProducts = new ArrayList<>();
        for (Integer productId : cartItems.keySet()) {
            Optional<Proizvod> productOpt = proizvodRepository.findById(productId);
            productOpt.ifPresent(orderedProducts::add);
        }

        // Associate ordered products with the user (attach it to their email)
        user.getOrderedProducts().addAll(orderedProducts);
        userRepository.save(user);  // Save the user with their associated ordered products

        return orderedProducts;
    }
    
    
    
    public List<ProductDto> getOrderedProductsByUserEmail(String email) {
    	
        Optional<User> userOpt = userRepository.findByEmail(email);
        
        if (userOpt.isPresent()) {
            User user = userOpt.get();
            
            // Fetch ordered products from the user entity and convert them to ProductDto
            List<Proizvod> orderedProducts = user.getOrderedProducts();
            
            // Convert Proizvod entities to ProductDto
            List<ProductDto> orderedProductDtos = new ArrayList<>();
            
            for (Proizvod proizvod : orderedProducts) {
            	
                ProductDto productDto = new ProductDto();
                productDto.setProizvodId(proizvod.getProizvod_ID());
                productDto.setImeProizvoda(proizvod.getIme_Proizvoda());
                productDto.setOpisProizvoda(proizvod.getOpis_Proizvoda());
                productDto.setCenaProizvoda(proizvod.getCena_Proizvoda());
                // Set other fields of ProductDto if necessary
                
                orderedProductDtos.add(productDto);
            }
            
            return orderedProductDtos;
        } else {
            return new ArrayList<>(); // Return an empty list if no user is found
        }
    }
    
    
    @Transactional
    public void addProductsToUser(User user, List<Proizvod> orderedProducts) {
    	
        user.getOrderedProducts().addAll(orderedProducts);
        
        userRepository.save(user);  // Ensure the user is saved after the changes
    }


    
}

    
    
