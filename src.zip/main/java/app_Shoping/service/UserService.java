package app_Shoping.service;

import java.util.List;

import app_Shoping.dto.UserDto;
import app_Shoping.model.Proizvod;
import app_Shoping.model.User;



public interface UserService {


	
	boolean saveUser(UserDto userDto);

    User findUserByEmail(String email);

    List<UserDto> findAllUsers();

	List<UserDto> getAllUsersWithOrderedProducts();

	UserDto findUserDtoByEmail(String name);

	void addProductsToUser(User user, List<Proizvod> orderedProducts);
    

}
	
	

