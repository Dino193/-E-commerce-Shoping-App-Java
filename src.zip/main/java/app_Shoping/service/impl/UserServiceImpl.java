package app_Shoping.service.impl;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import app_Shoping.dto.ProductDto;
import app_Shoping.dto.UserDto;
import app_Shoping.model.Proizvod;
import app_Shoping.model.Role;
import app_Shoping.model.User;
import app_Shoping.repository.ProizvodRepository;
import app_Shoping.repository.RoleRepository;
import app_Shoping.repository.UserRepository;
import app_Shoping.service.UserService;
import jakarta.transaction.Transactional;


@Service
public class UserServiceImpl implements UserService {

	
	@Autowired
    private UserRepository userRepository;

    @Autowired
    private RoleRepository roleRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;
    
    @Autowired
    private ProizvodRepository proizvodRepository;

    public UserServiceImpl(UserRepository userRepository,
                           RoleRepository roleRepository,
                           PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.roleRepository = roleRepository;
        this.passwordEncoder = passwordEncoder;
    }
    private static final Logger logger = LoggerFactory.getLogger(UserServiceImpl.class);


    @Override
    @Transactional
    public boolean saveUser(UserDto userDto) {
        try {
            User user = new User();
            user.setName(userDto.getFirstName() + " " + userDto.getLastName());
            user.setCity(userDto.getCity());
            user.setEmail(userDto.getEmail());
            user.setPassword(passwordEncoder.encode(userDto.getPassword()));

            // Safeguard against null roleIds
            List<Role> roles;
            if (userDto.getRoleIds() != null && !userDto.getRoleIds().isEmpty()) {
                roles = roleRepository.findAllById(userDto.getRoleIds());
            } else {
                Role defaultRole = checkRoleExist(); // Ensure at least one role
                roles = Arrays.asList(defaultRole);
            }
            user.setRoles(roles);

            userRepository.save(user);
            return true;
        } catch (Exception e) {
            logger.error("Error saving user: ", e);
            throw e; // Re-throw to ensure transaction rollback
        }
    }


		

    @Override
    @Transactional
    public User findUserByEmail(String email) {
        return userRepository.findByEmail(email)
                .orElseThrow(() -> new UsernameNotFoundException("User not found with email: " + email));
    }
	

	@Override
	@Transactional
	public List<UserDto> findAllUsers() {
		 List<User> users = userRepository.findAll();
		    return users.stream()
		            .map(this::mapToUserDto)
		            .collect(Collectors.toList());
		}
	
	
	public UserDto mapToUserDto(User user) {
	    UserDto userDto = new UserDto();
	    userDto.setId(user.getId());
	    userDto.setFirstName(user.getName().split(" ")[0]);
	    
	    // Safeguard to avoid ArrayIndexOutOfBoundsException
	    String[] nameParts = user.getName().split(" ");
	    if (nameParts.length > 1) {
	        userDto.setLastName(nameParts[1]);
	    } else {
	        userDto.setLastName(""); // or handle it accordingly
	    }

	    userDto.setCity(user.getCity());
	    userDto.setEmail(user.getEmail());
	    userDto.setPassword(user.getPassword());

	    // Assuming roles are being mapped correctly
	    List<Long> roleIds = user.getRoles().stream()
	                              .map(Role::getId)
	                              .collect(Collectors.toList());
	    userDto.setRoleIds(roleIds);

	    return userDto;
	}

	@Transactional
	private Role checkRoleExist() {
	    Role role = roleRepository.findByName("ROLE_USER");
	    if (role == null) {
	        role = new Role();
	        role.setName("ROLE_USER");
	        return roleRepository.save(role);
	    }
	    return role;
	}



	@Override
	@Transactional
	public List<UserDto> getAllUsersWithOrderedProducts() {
		
	    List<User> users = userRepository.findAll(); // Get all users
	    List<UserDto> userDtos = new ArrayList<>();

	    for (User user : users) {
	    	
	        UserDto userDto = convertToUserDto(user); // Assuming a method to convert User to UserDto
	        
	        // Find products ordered by the user
	        List<Proizvod> orderedProducts = proizvodRepository.findProductsByUserId(user.getId());
	        
	        // Convert the list of Proizvod entities to ProductDto
	        List<ProductDto> productDtos = new ArrayList<>();
	        for (Proizvod proizvod : orderedProducts) {
	            ProductDto productDto = convertToProductDto(proizvod); // Method to map Proizvod to ProductDto
	            productDtos.add(productDto);
	        }
	        
	        // Set the converted ProductDtos in the UserDto
	        userDto.setOrderedProducts(productDtos); 
	        userDtos.add(userDto); // Add the userDto to the list
	    }

	    return userDtos;
	}

	// Assuming you have a method to convert Proizvod entity to ProductDto
	private ProductDto convertToProductDto(Proizvod proizvod) {
	    return new ProductDto(
	        proizvod.getProizvod_ID(),
	        proizvod.getIme_Proizvoda(),
	        proizvod.getOpis_Proizvoda(),
	        proizvod.getCena_Proizvoda(),
	        null, // You can add logic to convert the image to base64 if needed
	        proizvod.getKategorija(),
	        proizvod.getBrand(),
	        proizvod.getSkladisteProizvoda()
	    );
	}


	private UserDto convertToUserDto(User user) {
	    UserDto userDto = new UserDto();
	    userDto.setId(user.getId());
	    
	    // Assuming you have a name-splitting logic if the full name is stored in one field
	    String[] nameParts = user.getName().split(" ");
	    userDto.setFirstName(nameParts[0]);
	    if (nameParts.length > 1) {
	        userDto.setLastName(nameParts[1]);
	    }
	    
	    userDto.setCity(user.getCity());
	    userDto.setEmail(user.getEmail());
	    
	    // other fields...
	    
	    return userDto;
	}
	
	
	// Find User by Email
	
    public UserDto findUserDtoByEmail(String email) {
    	
        User user = userRepository.findByEmail(email).orElseThrow(() -> new UsernameNotFoundException("User not found"));
        
        return convertToUserDto(user);
    }
    
    
    @Override
    @Transactional
    public void addProductsToUser(User user, List<Proizvod> orderedProducts) {
        
        user.getOrderedProducts().addAll(orderedProducts);
        
       
        userRepository.save(user);  
    }
    
}

	
	
	
	
	




	
	
	
	