package app_Shoping.security;

import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import app_Shoping.model.Role;
import app_Shoping.model.User;
import app_Shoping.repository.UserRepository;

import java.util.Collection;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class CustomUserDetailsService implements UserDetailsService {


	@Autowired
	private UserRepository userRepository;

   

	@Override
    public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
        // Use the Optional returned by findByEmail
        Optional<User> userOpt = userRepository.findByEmail(email);

        // If user is present, map to Spring Security's UserDetails
        return userOpt.map(user -> new org.springframework.security.core.userdetails.User(
                    user.getEmail(),
                    user.getPassword(),
                    mapRolesToAuthorities(user.getRoles())))
                .orElseThrow(() -> new UsernameNotFoundException("Invalid username or password."));
    }

    // Helper method to map roles to authorities
    private Collection<? extends GrantedAuthority> mapRolesToAuthorities(Collection<Role> roles) {
        return roles.stream()
                .map(role -> new SimpleGrantedAuthority(role.getName()))
                .collect(Collectors.toList());
    }
}

