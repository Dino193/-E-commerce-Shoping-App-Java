package app_Shoping.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import app_Shoping.model.Brand;

public interface BrandRepository extends JpaRepository<Brand, Integer>{

}
