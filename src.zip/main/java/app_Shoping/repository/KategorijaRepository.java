package app_Shoping.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import app_Shoping.model.Kategorija;

public interface KategorijaRepository  extends JpaRepository<Kategorija,Integer> {
	
	List<Kategorija> findByImeKategorijeStartingWithIgnoreCase(String letter);
	
	@Query("SELECT k FROM Kategorija k WHERE LOWER(k.imeKategorije) LIKE LOWER(CONCAT('%', :keyword, '%'))")
	List<Kategorija> findByImeKategorijeContainingIgnoreCase(@Param("keyword") String keyword);
	

}
