package app_Shoping.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import app_Shoping.model.SkladisteProizvoda;


public interface SkladisteProizvodaRepository extends JpaRepository<SkladisteProizvoda, Integer> {

}
