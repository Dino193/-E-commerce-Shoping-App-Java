package app_Shoping.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import app_Shoping.dto.ProductDto;
import app_Shoping.model.Proizvod;

public interface ProizvodRepository extends JpaRepository<Proizvod, Integer> {

	List<Proizvod> findByKategorija_KategorijaID(int Kategorija_ID);

	List<Proizvod> findAllById(Iterable<Integer> Proizvod_ID);

	List<Proizvod> findByKategorija_KategorijaIDIn(List<Integer> kategorijaIds);

	
	@Query("SELECT p FROM Proizvod p WHERE p.kategorija.kategorijaID IN :kategorijaIds AND p.Cena_Proizvoda BETWEEN :lowerPrice AND :upperPrice")
	List<Proizvod> findByKategorija_KategorijaIDInAndCena_ProizvodaBetween(
			@Param("kategorijaIds") List<Integer> kategorijaIds, @Param("lowerPrice") double lowerPrice,
			@Param("upperPrice") double upperPrice);


	
	@Query("SELECT p FROM Proizvod p JOIN p.users u WHERE u.id = :userId")
	List<Proizvod> findProductsByUserId(@Param("userId") Long id);
	
	
	
	
	
	
	@Query("SELECT p FROM Proizvod p WHERE LOWER(p.Ime_Proizvoda) LIKE LOWER(CONCAT('%', :keyword, '%')) " +
	            "AND p.Cena_Proizvoda BETWEEN :lowerPrice AND :upperPrice")
	    List<Proizvod> findByIme_ProizvodaContainingIgnoreCaseAndCena_ProizvodaBetween(
	            @Param("keyword") String keyword, @Param("lowerPrice") double lowerPrice, @Param("upperPrice") double upperPrice);

	    @Query("SELECT p FROM Proizvod p WHERE LOWER(p.Ime_Proizvoda) LIKE LOWER(CONCAT('%', :keyword, '%')) " +
	            "AND p.kategorija.kategorijaID IN :kategorijaIds " +
	            "AND p.Cena_Proizvoda BETWEEN :lowerPrice AND :upperPrice")
	    List<Proizvod> findByIme_ProizvodaContainingIgnoreCaseAndKategorija_KategorijaIDInAndCena_ProizvodaBetween(
	            @Param("keyword") String keyword, @Param("kategorijaIds") List<Integer> kategorijaIds,
	            @Param("lowerPrice") double lowerPrice, @Param("upperPrice") double upperPrice);

	    @Query("SELECT DISTINCT p.Ime_Proizvoda FROM Proizvod p")
	    List<String> findDistinctProductNames();
	}



	


