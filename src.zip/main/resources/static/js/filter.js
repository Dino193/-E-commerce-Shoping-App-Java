   function filterProductsByCategory(radioButton) {
      var categoryId = radioButton.getAttribute("data-category-id");
      var products = document.querySelectorAll('.product-item');
      products.forEach(function(product) {
          if (product.getAttribute("data-category-id") === categoryId) {
              product.style.display = "block";
          } else {
              product.style.display = "none";
          }
      });
    }