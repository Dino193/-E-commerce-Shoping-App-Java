// Function to fetch ordered products for each user using AJAX
function fetchOrderedProducts(userId, userEmail) {
    // AJAX call to the server to get ordered products for the user
    $.ajax({
        url: '/fetchOrderedProducts', // Adjust the URL to match your backend endpoint
        method: 'GET',
        data: { email: userEmail }, // Pass the email as a parameter
        success: function(response) {
            // Clear the existing product list for this user
            $('#orderedProducts-' + userId).empty();
            
            // Populate the ordered products for this user
            response.forEach(function(product) {
                $('#orderedProducts-' + userId).append('<li>' + product.imeProizvoda + '</li>');
            });
        },
        error: function(xhr, status, error) {
            console.error('Failed to fetch products:', error);
        }
    });
}

// On window load, fetch the ordered products for each user
window.onload = function() {
    // Loop through each user and call fetchOrderedProducts function
    var users = window.usersData; // Global variable with users data injected from Thymeleaf
    users.forEach(function(user) {
        fetchOrderedProducts(user.id, user.email);
    });

    // Display Toastr notifications based on messages
    var msg = window.toastrMessage || 'default';
    if (msg === "Save Success") {
        toastr.success("Item added successfully!!");
    } else if (msg === "Delete Success") {
        toastr.success("Item deleted successfully!!");
    } else if (msg === "Delete Failure") {
        toastr.error("Some error occurred, couldn't delete item");
    } else if (msg === "Edit Success") {
        toastr.success("Item updated successfully!!");
    }

    toastr.options = {
        "closeButton": true,
        "debug": false,
        "newestOnTop": false,
        "progressBar": true,
        "positionClass": "toast-top-right",
        "preventDuplicates": false,
        "showDuration": "300",
        "hideDuration": "1000",
        "timeOut": "5000",
        "extendedTimeOut": "1000",
        "showEasing": "swing",
        "hideEasing": "linear",
        "showMethod": "fadeIn",
        "hideMethod": "fadeOut"
    };
}




//PRICE FILTER
    function updatePriceValues() {
        // Get the values of the range inputs
        const lowerPrice = document.getElementById('price-range-lower').value;
        const upperPrice = document.getElementById('price-range-upper').value;

        // Update the displayed values
        document.getElementById('lower-value').textContent = lowerPrice;
        document.getElementById('upper-value').textContent = upperPrice;
    }



//ADD PROIZVOD AT CART
function addToCart(proizvodId, quantity) {
    fetch('/cart/add', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded'
        },
        body: new URLSearchParams({
            'productId': proizvodId,
            'quantity': quantity
        })
    })
    .then(response => {
        if (response.ok) {
            // Redirect to the cart page after adding the product
            window.location.href = '/cart';
        } else {
            alert('Failed to add the product to the cart.');
        }
    })
    .catch(error => {
        console.error('Error:', error);
    });
}

function getQuantity() {
    return document.getElementById('sst').value;
}


//REMOVE PROIZVOD FROM CART
function removeFromCart(proizvodId) {
	  // Send request to server to remove the product
	  fetch('/cart/remove', {
	    method: 'POST',
	    headers: {
	      'Content-Type': 'application/json',
	    },
	    body: JSON.stringify({ productId: proizvodId }),
	  })
	    .then(response => response.json())
	    .then(data => {
	      // Reload the page or update the cart display
	      if (data.success) {
	        window.location.reload(); // Reload to reflect cart changes
	      } else {
	        alert("Failed to remove the product from the cart.");
	      }
	    })
	    .catch(error => console.error('Error:', error));
	}

//ADD TO CONFIRMATION PAGE
function addToOrderConfirmation(proizvodId, quantity) {
    fetch('/orderConfirmation/add', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded'
        },
        body: new URLSearchParams({
            'productId': proizvodId,
            'quantity': quantity
        })
    })
    .then(response => {
        if (response.ok) {
            // Redirect to the cart page after adding the product
            window.location.href = '/Order-Confirmation';
        } else {
            alert('Failed to add the product to the cart.');
        }
    })
    .catch(error => {
        console.error('Error:', error);
    });
}

function getQuantity() {
    return document.getElementById('sst').value;
}


$(function() {
	"use strict";

	//------- Parallax -------//
	skrollr.init({
		forceHeight: false
	});

	//------- Active Nice Select --------//
	$('select').niceSelect();

	//------- hero carousel -------//
	$(".hero-carousel").owlCarousel({
		items: 3,
		margin: 10,
		autoplay: false,
		autoplayTimeout: 5000,
		loop: true,
		nav: false,
		dots: false,
		responsive: {
			0: {
				items: 1
			},
			600: {
				items: 2
			},
			810: {
				items: 3
			}
		}
	});

	//------- Best Seller Carousel -------//
	if ($('.owl-carousel').length > 0) {
		$('#bestSellerCarousel').owlCarousel({
			loop: true,
			margin: 30,
			nav: true,
			navText: ["<i class='ti-arrow-left'></i>", "<i class='ti-arrow-right'></i>"],
			dots: false,
			responsive: {
				0: {
					items: 1
				},
				600: {
					items: 2
				},
				900: {
					items: 3
				},
				1130: {
					items: 4
				}
			}
		})
	}

	//------- single product area carousel -------//
	$(".s_Product_carousel").owlCarousel({
		items: 1,
		autoplay: false,
		autoplayTimeout: 5000,
		loop: true,
		nav: false,
		dots: false
	});

	//------- mailchimp --------//  
	function mailChimp() {
		$('#mc_embed_signup').find('form').ajaxChimp();
	}
	mailChimp();

	//------- fixed navbar --------//  
	$(window).scroll(function() {
		var sticky = $('.header_area'),
			scroll = $(window).scrollTop();

		if (scroll >= 100) sticky.addClass('fixed');
		else sticky.removeClass('fixed');
	});

	//------- Price Range slider -------//
	if (document.getElementById("price-range")) {

		var nonLinearSlider = document.getElementById('price-range');

		noUiSlider.create(nonLinearSlider, {
			connect: true,
			behaviour: 'tap',
			start: [500, 4000],
			range: {
				// Starting at 500, step the value by 500,
				// until 4000 is reached. From there, step by 1000.
				'min': [0],
				'10%': [500, 500],
				'50%': [4000, 1000],
				'max': [10000]
			}
		});


		var nodes = [
			document.getElementById('lower-value'), // 0
			document.getElementById('upper-value')  // 1
		];

		// Display the slider value and how far the handle moved
		// from the left edge of the slider.
		nonLinearSlider.noUiSlider.on('update', function(values, handle, unencoded, isTap, positions) {
			nodes[handle].innerHTML = values[handle];
		});

	}

});


